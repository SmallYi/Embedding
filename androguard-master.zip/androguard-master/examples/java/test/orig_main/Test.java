
public class Test {
    
    
    public Test() {
    }
            
    public static void main(String args[]) {

        Test1 t = new Test1();
        t.go();
    }
    
}
