import numpy as np
#simport matplotlib.mlab as mlab
import matplotlib.pyplot as plt
import string
#print 11
filepath="../output3/opcodenum.txt"
file=open(filepath,'r')
x=[i for i in range(0,3000000,10000)]
y=[]

for line in file:
    y.append(int(string.atof(line.replace("\r\n",""))*152789/7204))

print y

fig=plt.figure(1)

plt.plot(x,y,'--',0.4, color="black")
#size1=['0-100000','10-20','20-30','30-40','40-50','50-60','60-70','70-80','80-90','90-100','100-110','110-120','120-130','130-140','140-150']
#print y
#plt.xlim(0,30000000)
#plt.ylim(0,300)
#size1=['0','0.5','1.0','1.5','2.0','2.5','3.0']
#plt.xticks(size1)
#plt.xscale('log')
plt.xlabel('number of opcodes per app')
plt.ylabel('number for corrending opcodes')
plt.title('number for corrending opcodes per app')
plt.grid(color='black',linewidth='0.3',linestyle='--')
plt.show()
