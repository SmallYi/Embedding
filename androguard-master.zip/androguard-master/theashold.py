import sys
import os
import numpy
import string
import random
import matplotlib.pyplot as plt 
#import pylab as pl
#from matplotlib.ticker import MultipleLocator, FormatStrFormatter
#from pylab import *

filename="../output5/threashold.txt"
infilename=open(filename,'r')
x=[x for x in numpy.arange(0.0001, 0.3, 0.0001)]
y=[]
for line in infilename:
    print string.atof(line.replace("\r\n",""))/20529.00
    y.append((string.atof(line.replace("\r\n",""))/20529.00)*100)
plt.plot(x,y, '*',color='black')
#plt.legend(loc='lower right',prop={'size': 10})
#yticks=range(0,1.0,0.5)
#plt.xlim(0.0,1.0)
#plt.ylim(0.0,1.0)
plt.grid(color='black',linewidth='0.3',linestyle='--')
#plt.yscale("log")
plt.xlabel('Function Similarity Threshold')
plt.ylabel('TPR (%)')
#plt.title('TPR in different similarity threshold') 

#plt.grid(True)

#................................................................................
#plt.legend()
plt.show()
