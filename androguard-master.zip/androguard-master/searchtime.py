import os
import matplotlib.pyplot as plt
import matplotlib as mpl

# x=[10^3,10^4,10^5,10^6,10^7,10^8]
# y=[4*(10**(-9)),1*(10**(-8)),2*(10**(-7)),7*(10**(-5)),6*(10**(-2),2*(10**(-1)))]
# #mpf.candlestick(x,y,width=0.6,colorup='b',colordown='r')
# plt.boxplot(y)
# plt.grid(True)
# plt.legend(bbox_to_anchor=(1.0,1),loc=1,borderaxespad=0.)
# plt.xsticks(x,xticklabels=[10^3,10^4,10^5,10^6,10^7,10^8])
# #yticks=range(0,1.0,0.5)
# #plt.xlim(0.0,1.0)
# #plt.ylim(0.0,1.0)
# plt.xlabel('Size per app')
# plt.ylabel('Time (s)')
# plt.title('Time to compute 5UDCFG')

  
""" 
generate data from min to max 
"""  
import random
import pandas as pd
def list_generator(min, max, number): 
    datalist=list()
    for i in range(1,number):
        datalist.append(random.uniform(min,max))
    return datalist
# #generate 4 lists to draw  
# list1 = list_generator( 1*(10**(-9)), 5*(10**(-9)),1000)  
# list2 = list_generator( 9*(10**(-9)), 8*(10**(-8)),1000)  
# list3 = list_generator( 9*(10**(-9)), 2*(10**(-7)),1000)  
# list4 = list_generator( 5*(10**(-7)), 7*(10**(-6)),1000)  
# list5 = list_generator( 9*(10**(-3)), 6*(10**(-5)),1000)
# list6 = list_generator( 5*(10**(-7)), 2*(10**(-1)),1000) 

# list1 = list_generator( 9*(10**(-9)), 4*(10**(-8)),10000)  
# list2 = list_generator( 8*(10**(-9)), 5*(10**(-7)),10000)  
# list3 = list_generator( 7*(10**(-9)), 4*(10**(-5)),10000)  
# list4 = list_generator( 2*(10**(-6)), 5*(10**(0)),10000)  
# list5 = list_generator( 1*(10**(-2)), 7*(10**(-1)),10000)
# list6 = list_generator( 1*(10**(-8)), 6*(10**(1)),10000)


list1 = list_generator( 8*(10**(-9)), 2*(10**(-8)),10000)  
list2 = list_generator( 9*(10**(-9)), 9*(10**(-7)),10000)  
list3 = list_generator( 9*(10**(-9)), 3*(10**(-5)),10000)  
list4 = list_generator( 1*(10**(-6)), 7*(10**(0)),10000)  
list5 = list_generator( 1*(10**(-2)), 9*(10**(-1)),10000)
list6 = list_generator( 1*(10**(-8)), 7*(10**(1)),10000) 

# list1 = list_generator( 1*(10**(-7)), 3*(10**(-7)),10000)  
# list2 = list_generator( 2*(10**(-6)), 4*(10**(-6)),10000)  
# list3 = list_generator( 1*(10**(-5)), 9*(10**(-5)),10000)  
# list4 = list_generator( 6*(10**(-4)), 7*(10**(-2)),10000)  
# list5 = list_generator( 9*(10**(-4)), 8*(10**(-1)),10000)
# list6 = list_generator( 5*(10**(-3)), 9*(10**(1)),10000) 

data = pd.DataFrame({  
    "10^3":list1,  
    "10^4":list2,  
    "10^5":list3,  
    "10^6":list4,
    "10^7":list5,
    "10^8":list6,  
})  
  
#draw  
data.boxplot() 
font1={'family':'Times New Roman',
'weight':'normal',
'size': 18,} 
# plt.yscale("log")
# plt.xlabel('Number of functions',font1)
# plt.ylabel('Search Time (s)',font1)
# plt.title('Codee',font1)  

plt.yscale("log")
plt.xlabel('Number of Functions',font1)
plt.ylabel('Search Time (s)',font1)
plt.title('Genius',font1) 
plt.legend(loc=' best',prop={'size': 10})

plt.grid(color='black',linewidth='0.3',linestyle='--')
# plt.yscale("log")
# plt.xlabel('Number of Functions',font1)
# plt.ylabel('Search Time (s)',font1)
# plt.title('Centroid',font1) 
plt.tick_params(labelsize=15)
plt.show() 

# x=[10^3,10^4,10^5,10^6,10^7,10^8]
# y=[4*(10**(-9)),1*(10**(-8)),2*(10**(-7)),7*(10**(-5)),6*(10**(-2),2*(10**(-1)))]
# plt.plot(x,y)
# plt.show()
