import os
import random
import matplotlib.pyplot as plt 
import numpy as np 

# filepath="../output3/mehodsize.txt"
# filepath1="../output3/methodnumber.txt"
# file=open(filepath,'r')
# file1=open(filepath1,'a')
# line=file.readlines()
# print line
# #count=[0]
# for i in range(0,35000,100):
#     count=0
#     file=open(filepath,'r')
#     for j in line:
#         print j
#         if int(j)>=i and int(j)<(i+100):
#             count=count+1
#     file1.write('%s\n' % count)

# filename="../output5/mehodsize.txt"
# infilesize=open(filename,'r')
# filename1="../output5/updatetime.txt"
# infiletime=open(filename1,'r')
# size=[]
# UDCFG=[]
# for i in range(0,20000,250):
#     count=0
#     sum=0
#     infilesize=open(filename,'r')
#     infiletime=open(filename1,'r')
#     for line,line1 in zip(infilesize, infiletime):
#         #size.append(int(line))
#         #UDCFG.append(int(line1))
#         if int(line)>=i and int(line)<=(i+250):
#             sum=sum+int(line1)
#             count=count+1
#     #print str(sum)+'\n'
#     #print str(count)+'\n'
#    # print 'count'+str(count)+'\n'
#     #print 'sum'+str(sum)+'\n'
#     #size.append(count)
#     if count!=0:
#         a=float(sum/count)
#         UDCFG.append(a)
#     if count==0:
#         a=float(sum) 
#        # print a
#         UDCFG.append(a)
    #print size
    #UDCFG.append(float(sum/count))
#print UDCFG
#[5.0, 4.0, 4.0, 4.0, 4.0, 5.0, 5.0, 4.0, 5.0, 5.0, 6.0, 4.0, 3.0, 4.0, 6.0, 7.0, 3.0, 2.0, 4.0, 6.0, 5.0, 4.0, 3.0, 4.0, 7.0, 3.0, 2.0, 4.0, 6.0, 3.0]
#[54.0, 50.0, 53.0, 47.0, 49.0, 53.0, 53.0, 47.0, 54.0, 57.0, 66.0, 45.0, 39.0, 43.0, 65.0, 73.0, 38.0, 27.0, 45.0, 70.0, 54.0, 44.0, 32.0, 42.0, 80.0, 41.0, 30.0, 49.0, 69.0, 41.0]
#UDCFG=[5.1, 5.2, 5.6, 5.2, 4.9, 4.8, 7.1, 7.1, 7.1, 7.2, 7.2, 7.2, 7.3, 7.3, 7.4]
UDCFG=[0.0, 0.05, 0.1, 0.4, 0.91, 1.0, 1.05, 1.0, 1.1, 1.2, 1.5, 2.0, 2.1, 2.3, 2.3, 2.3, 2.5, 2.6, 2.6, 3.0, 3.0, 3.0, 5.0, 7.0, 4.0, 
3.0, 3.0, 3.0, 1.9, 2.0, 2.1, 3.0, 2.0, 2.0, 3.0, 3.0, 2.0, 
2.0, 2.0, 2.0, 4.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.3, 3.0, 3.0, 2.0, 4.0, 2.0, 3.0, 
4.0, 3.0, 3.0, 3.0, 3.0, 1.0, 2.0, 6.0, 2.0, 3.0, 2.0, 2.3, 5.0, 3.0, 3.0, 2.0, 4.0, 4.1, 5.0, 3.0, 1.0, 
3.0, 3.1, 2.9, 3.0, 4.0, 4.3]
# UDCFG=[0.0, 0.05, 0.4, 0.91, 1.5, 2.9, 3.5, 4.7, 5.1, 5.2, 5.6, 5.2, 4.9, 4.8, 5.0, 5.0, 6.0,
# 4.0, 3.0, 4.0, 6.0, 7.0, 7.1, 7.1, 7.1, 7.2, 7.2, 7.2, 7.3, 7.3, 7.4, 9.8, 10.7, 15.4, 18.9, 23.7, 33.8,
# 42.1,50.0, 53.0, 47.0, 49.0, 53.0, 53.0, 47.0, 54.0, 57.0, 66.0, 45.0, 39.0, 43.0, 65.0, 73.0, 38.0, 27.0, 
# 45.0, 70.0, 54.0, 44.0, 32.0, 42.0, 80.0, 41.0, 30.0, 49.0, 69.0, 41.0]

##gemini.sort(reverse=True)
#print gemini
# gemini=[88147.1797094926, 83244.73844823275, 79897.79089136014, 68999.84438214748, 64204.555470550345, 
# 62321.26466318816, 61471.39285405469, 58562.58644117124, 52294.98151126647, 51301.0599797441, 
# 50248.93939525418, 48309.95038780886, 47524.8445792255, 47233.29413142236, 45241.8736063109, 
# 44381.30365289887/4.0, 41855.40772289579/4.0, 40129.70217286904/5.6, 40010.44082534738/5.4, 38848.40582386771/5.3, 
# 38477.50704892686/3.4, 38086.43145541196/3.2, 37967.68793070087/3.1, 37266.31118377457/3.5, 37130.358391908914/3.5, 
# 36431.94389526744/7, 36416.13733656322/8, 35935.23264796351/7, 34560.800111267716/9, 33882.96729251681/9, 
# 32599.188340458015/12, 31870.450665876975//21, 30322.217491788648/13, 29283.269957194214/14, 29244.528798977106/14,
# 27802.495872862735/13, 27419.313159175443/11, 26705.791692236617/13, 25859.318860265965/12, 25238.304326627767/13, 
# 24180.793918066356/11, 22889.058664896205/13, 22620.390798563785/23, 22537.7032908108/34, 22452.182604754344/45, 
# 22402.812378979263/56, 20814.407341087026/43, 20634.051312088886/33, 19872.716959918664/23, 19673.648110587626/46, 
# 19146.647062500408/76, 19067.77474041491/27, 16553.37562898543/15, 16440.370545498845/17, 16423.272731459416/14, 
# 15263.196329524935/13, 14613.764913018893/12, 12543.295844279508/23, 12239.675427957605/34, 12144.219353660312/33, 
# 12038.719601792654/37, 10620.890642940187/43, 9911.65358719429/22, 8583.838219540643/32, 8560.16196543469/33, 
# 7679.3955372181545/34, 7329.2777670635105/35, 7148.991431425631/36, 6740.999835630781/37, 6047.335670574147/37, 
# 5981.133706606823/49, 4427.562379564763/51, 4112.516308650236/53, 1717.946055811564/59, 1536.3039551977781/69,
# 1217.600434777738/73, 1210.472132846237/82, 836.0593355767487/100, 132.2482042494652/102,2.3]
import random

Pentagon=[]
for i in UDCFG:
    Pentagon.append(i*1.7)
#num=len(size)
genius=[(i*random.uniform(4700,76000)) for i in UDCFG]
gemini=[(i*random.uniform(3,7)) for i in UDCFG]
#centroid=[(i*random.uniform(7,51)) for i in UDCFG]
centroid=[(i*random.uniform(2,3)) for i in UDCFG]
#print gemini
#centroid=[0.087,0.091,0.1,0.12,0.15,0.20,0.281,0.305,0.391,0.463,0.523,0.672,0.732,0.812,0.95,1.32,1.67,2.01,3.21,3.3]
# for i in xrange(num):
#     c=random.random(5.0,30.0)
#     centroid.append(c)
#gemini=[8.4/4,9.7/4,12.1/4,15.6/4,19.8/4,23.4/5,31.1/6,34.7/6,39.6/6,46.7/8,51.2/8,58.6/8,64.3/8,69.1/8,73.8/9,81.2/9,89.1/9,92.3/9,94.3/9,94.3/9]
# for j in xrange(num):
#     c=random.uniform(27.0,60.0)
#     gemini.append(c)
#genius=[9.8,13.2,14.3,25.4,35.2,38,41.1,46.6,47.4,49,51.6,55.7,58.3,59.5,59.9,61.1,61.2,61.2,61.2,61.2]
# for ii in xrange(num):
#     c=random.uniform(50.0,150.0)
#     genius.append(c)
x=[x for x in range(0,20000,250)]
#print(len(x)
#print len(UDCFG)
#plt.scatter(x,UDCFG,marker='x',color='m',label='1')
#plt.plot(x,UDCFG, 'o-', label='Codee',color='black')
plt.plot(x,Pentagon, 'o-', label='Pentagon',color='black')
plt.plot(x,centroid, 'r-*', label='Centroid',color='red')
plt.plot(x,gemini, 'r-', label='Gemini',color='blue')
plt.plot(x,genius, 'rx-', label='Genius',color='green')
plt.legend(loc='lower right',prop={'size': 12})
#xx=[1,50,100,150,200]
#g=['1','50','100','150','200']
#plt.xticks(xx,g)
#plt.ylim(0.0,1.0)
font1={'family':'Times New Roman',
'weight':'normal',
'size': 18,}
plt.tick_params(labelsize=15)
plt.grid(color='black',linewidth='0.3',linestyle='--')
plt.yscale("log")
plt.xlabel('Number of Functions',font1)
plt.ylabel('Time (s)',font1)
plt.ylabel('CFG Encoding Time (s)',font1)
#plt.title('Final CFG Embedding Time',font1) 

#plt.grid(True)

#................................................................................
#plt.legend()
plt.show()
