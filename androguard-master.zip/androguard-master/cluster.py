import sys
import os
import numpy
import string
import random
import matplotlib.pyplot as plt 
#import pylab as pl
#from matplotlib.ticker import MultipleLocator, FormatStrFormatter
#from pylab import *

cluster_number=[x for x in range(8, 42, 2)]
TPR1=[98.9, 98.5, 98.9, 94.2, 78.1, 57.1, 86.3, 55.2, 95.2, 94.9, 74.6, 95.6, 87.2, 74.9, 57.0, 62.6, 89.3]
plt.plot(cluster_number,TPR1, '^', label='TPR',color='black')
plt.xlabel('The number of clustering')
plt.ylabel('TPR (%)')
plt.title('TPR in different clustering number')
plt.legend(loc='lower right',prop={'size': 10})
#yticks=range(0,1.0,0.5)
#plt.xlim(0.0,1.0)
#plt.ylim(0.0,1.0)
plt.grid(color='black',linewidth='0.3',linestyle='--')
#plt.yscale("log")
#plt.xlabel('Similarity threshold')
#plt.ylabel('TPR')
#plt.title('TPR in different similarity threshold') 

#plt.grid(True)

#................................................................................
#plt.legend()
plt.show()
